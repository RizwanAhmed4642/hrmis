import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute, Router } from '@angular/router';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { User } from '../../../../_models/user.class';
import { KGridHelper } from '../../../../_helpers/k-grid.class';
import { DropDownsHR } from '../../../../_helpers/dropdowns.class';
import { NotificationService } from '../../../../_services/notification.service';
import { RootService } from '../../../../_services/root.service';
import { AuthenticationService } from '../../../../_services/authentication.service';
import { PandSOfficerView, PandSOfficerFilters } from '../../user-claims.class';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-officers-add-edit',
  templateUrl: './add-edit.component.html',
  styles: []
})
export class AddEditComponent implements OnInit, OnDestroy {
  @ViewChild('fpImageRef', { static: false }) fpImage = '';
  @ViewChild('fpRef', { static: false }) fptxt = '';
  public currentUser: User;
  public currentOfficer: any;
  public officer: any = {};
  public officerFingerPrints: any[] = [];
  public cadres: any[] = [];
  public designations: any[] = [];
  public userId: string = '';
  public officerId: number = 0;
  public selectedOfficer_Id: number = 0;
  public selectedCadre_Id: number = 0;
  public selectedDesignation_Id: number = 0;
  public kGrid: KGridHelper = new KGridHelper();
  public dropDowns: DropDownsHR = new DropDownsHR();
  public pSOfficerFilters: any = {};
  public inputChange: Subject<any>;
  public searchQuery: string = '';
  public cnicMask: string = "00000-0000000-0";
  public mobileMask: string = "0000-0000000";
  public savingOfficer: boolean = false;
  public addingOfficer: boolean = false;
  public addingDesignation: boolean = false;
  public addingCadre: boolean = false;
  public iNumber: number = 1;
  public isSending: boolean = false;
  public registerFp: boolean = false;
  public relatedData: any = { concernedOfficers: [], concernedDesignations: [], concernedCadres: [], fps: [] };
  public subscription: Subscription;
  constructor(private route: ActivatedRoute,
    public _notificationService: NotificationService,
    private router: Router,
    private _rootService: RootService,
    private _authenticationService: AuthenticationService,
    private _userSerivce: UserService) { }

  ngOnInit() {
    this.currentOfficer = this._authenticationService.getCurrentOfficer();
    this.fetchParams();
    this.getDesignations();
    this.getCadres();
    this.getPandSOfficers('all');
  }
  private fetchParams() {
    this.subscription = this.route.params.subscribe(
      (params: any) => {
        if (params.hasOwnProperty('officerId') && params.hasOwnProperty('userId')) {
          this.pSOfficerFilters = new PandSOfficerFilters();
          this.pSOfficerFilters.User_Id = params['userId'];
          this.pSOfficerFilters.OfficerId = +params['officerId'];
          if (this.pSOfficerFilters.User_Id && this.pSOfficerFilters.OfficerId != 0) {
            this.getOfficer();
          }
        }
      }
    );
  }
  public getOfficer() {
    this._rootService.getOfficerData(this.pSOfficerFilters.User_Id, this.pSOfficerFilters.OfficerId).subscribe((response: any) => {
      if (response && response.officer) {
        this.officer = response.officer;
        this.relatedData.concernedOfficers = response.concernedOfficers;
        this.relatedData.concernedCadres = response.concernedCadres;
        this.relatedData.concernedDesignations = response.concernedDesignations;
        this.relatedData.fps = response.fingerPrints;
        this.dropDowns.selectedFiltersModel.designation = { Id: this.officer.Designation_Id, Name: this.officer.HrDesignationName }
      } else {
        this.officer = {};
      }
    }, err => {
      this.handleError(err);
    });
  }
  public sendData(value: any) {
    if (value == '' || this.iNumber > 5) {
      return;
    }
    this.isSending = true;
    this._userSerivce.postFPsDataBeta({ metaData: value }, this.officer.Id, this.iNumber).subscribe((x) => {
      if (x) {
        this.iNumber++;
        this.isSending = false;
      }
    });
  }
  private getDesignations = () => {
    this._rootService.getDesignations().subscribe((res: any) => {
      if (res) {
        this.designations = res;
        this.dropDowns.designations = res;
        this.dropDowns.designationsData = this.dropDowns.designations.slice();
      }

    },
      err => { this.handleError(err); }
    );
  }
  private getPandSOfficers = (type: string) => {
    this.dropDowns.officers = [];
    this._rootService.getPandSOfficers(type).subscribe((res: any) => {
      if (res) {
        this.dropDowns.officers = res;
      }
    },
      err => { this.handleError(err); }
    );
  }
  private getCadres = () => {
    this._rootService.getCadres().subscribe((res: any) => {
      if (res) {
        this.dropDowns.cadres = res;
      }
    },
      err => { this.handleError(err); }
    );
  }
  public dropdownValueChanged = (value, filter) => {
    if (!value) {
      return;
    }
    if (filter == 'designation') {
      this.officer.Designation_Id = value.Id;
    }
    if (filter == 'officer') {
      console.log(value.Id);
    }
  }
  public onSubmit(value: any) {
    this.savingOfficer = true;
    this._userSerivce.saveOfficer(this.officer).subscribe((x) => {
      if (x) {
        this.router.navigate(['/user/officer']);
      }
      this.savingOfficer = false;
    }, err => {
      console.log(err);
      this.savingOfficer = false;
    });
    console.log(value);
  }
  public addOfficerData(type: number, add: boolean) {
    if (this.pSOfficerFilters.add) {
      this._notificationService.notify('success', 'Saved Successfully');
      this.addingOfficer = true;
    }
    this.pSOfficerFilters.tableType = type;
    this.pSOfficerFilters.add = add;
    this._userSerivce.saveOfficerData(this.pSOfficerFilters).subscribe((res: any) => {
      if (res) {
        if (this.pSOfficerFilters.add) {
          this._notificationService.notify('success', 'Saved Successfully');
        } else {
          this._notificationService.notify('success', 'Removed Successfully!');
        }
        this.getOfficer();
        this.addingOfficer = false;
      }
    }, err => {
      this.handleError(err);
    });
  }
  public removeOfficerData(type: number, id: number) {
    this.pSOfficerFilters.concernedId = id;
    this.addOfficerData(type, false);
  }
  public sortChange(sort: SortDescriptor[]): void {
    if (sort[0].field == 'asd') { return; }
    this.kGrid.sort = sort;
    this.sortData();
  }
  private sortData() {
    this.kGrid.gridView = {
      data: orderBy(this.kGrid.data, this.kGrid.sort),
      total: this.kGrid.totalRecords
    };
  }
  public dashifyCNIC(cnic: string) {
    return cnic[0] +
      cnic[1] +
      cnic[2] +
      cnic[3] +
      cnic[4] +
      '-' +
      cnic[5] +
      cnic[6] +
      cnic[7] +
      cnic[8] +
      cnic[9] +
      cnic[10] +
      cnic[11] +
      '-' +
      cnic[12];
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  private handleError(err: any) {
    this.kGrid.loading = false;
    if (err.status == 403) {
      this._authenticationService.logout();
    }
  }
}
