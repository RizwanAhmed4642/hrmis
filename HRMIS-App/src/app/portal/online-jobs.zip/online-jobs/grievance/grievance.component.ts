import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grievance',
  templateUrl: './grievance.component.html',
  styles: []
})
export class GrievanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
