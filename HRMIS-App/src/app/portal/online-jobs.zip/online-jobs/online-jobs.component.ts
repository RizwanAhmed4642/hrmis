import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-posting',
  templateUrl: './online-posting.component.html',
  styles: []
})
export class OnlinePostingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
